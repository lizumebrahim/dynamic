tinyMCE.addI18n('el.smextensions',{
	desc : 'Sitemagic extensions'
});
