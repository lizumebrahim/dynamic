tinyMCE.addI18n('de.smextensions_dlg',{
	title : 'Sitemagic Erweiterungen',
	extension : 'Erweiterung'
});
