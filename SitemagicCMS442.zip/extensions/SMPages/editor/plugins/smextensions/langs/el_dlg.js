tinyMCE.addI18n('el.smextensions_dlg',{
	title : 'Sitemagic extensions',
	extension : 'Extension'
});
