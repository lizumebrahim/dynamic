tinyMCE.addI18n('en.smextensions',{
	desc : 'Sitemagic extensions'
});
