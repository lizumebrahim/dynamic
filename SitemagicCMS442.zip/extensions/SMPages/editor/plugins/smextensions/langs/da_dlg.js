tinyMCE.addI18n('da.smextensions_dlg',{
	title : 'Sitemagic udvidelser',
	extension : 'Udvidelse'
});
