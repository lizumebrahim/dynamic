tinyMCE.addI18n('en.smextensions_dlg',{
	title : 'Sitemagic extensions',
	extension : 'Extension'
});
