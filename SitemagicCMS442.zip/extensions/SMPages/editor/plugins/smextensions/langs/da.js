tinyMCE.addI18n('da.smextensions',{
	desc : 'Sitemagic udvidelser'
});
