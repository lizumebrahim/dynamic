tinyMCE.addI18n('de.smextensions',{
	desc : 'Sitemagic Erweiterungen'
});
