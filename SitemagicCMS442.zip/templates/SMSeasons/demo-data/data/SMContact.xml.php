<?php exit(); ?>
<?xml version="1.0" encoding="ISO-8859-1"?>
<database>
	<entry id="8ff89f59524a305b944b057aea658492" title="Name *" type="Textfield" position="1"/>
	<entry id="cd855cc2a868fa2174a537e72e3abfe8" title="E-mail *" type="Email" position="2"/>
	<entry id="f8fe77b10ebf8d9e88434b34a04e9fad" title="Message" type="Textbox" position="4"/>
	<entry id="203d7907a68678186cc97fed082839d1" title="Phone" type="Textfield" position="3"/>
</database>