<?php exit(); ?>
<?xml version="1.0" encoding="ISO-8859-1"?>
<database>
	<entry key="SMGalleryColumns" value="1"/>
	<entry key="SMGalleryRows" value="2"/>
	<entry key="SMGalleryWidth" value=""/>
	<entry key="SMGalleryHeight" value="180"/>
	<entry key="SMGalleryPadding" value="3"/>
	<entry key="SMContactRecipients" value="mail@example-domain.com"/>
	<entry key="SMContactSubject" value="Website Contact Form"/>
	<entry key="SMContactSuccessMessage" value="Thanks, we will get back to you shortly"/>
	<entry key="SMImageMontageMinHeight" value="100"/>
	<entry key="SMImageMontageMaxHeight" value="300"/>
	<entry key="SMImageMontageMargin" value="0"/>
	<entry key="SMImageMontageDisplayTitle" value="true"/>
	<entry key="SMImageMontageDisplayImageTitle" value="false"/>
	<entry key="SMImageMontageDisplayImageExif" value="false"/>
	<entry key="SMImageMontageDisplayPicker" value="false"/>
	<entry key="SMImageMontageShuffle" value="true"/>
	<entry key="SMImageMontageSlideShowInterval" value="3000"/>
</database>
